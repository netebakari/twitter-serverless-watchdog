"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv = __importStar(require("dotenv"));
dotenv.config();
const getEnv = (name) => {
    const result = process.env[name];
    if (result === undefined) {
        throw new Error(`environment variable "${name}" not defined`);
    }
    return result;
};
const twitterToken = {
    consumer_key: getEnv("consumer_key"),
    consumer_secret: getEnv("consumer_secret"),
    access_token: getEnv("access_token"),
    access_token_secret: getEnv("access_token_secret"),
};
exports.twitterToken = twitterToken;
const dynamoDb = {
    tableName: getEnv("dynamoDbTableName"),
    keyName: getEnv("dynamoDbKeyName"),
    keyValue: getEnv("dynamoDbKeyValue"),
    region: getEnv("region"),
};
exports.dynamoDb = dynamoDb;
const s3 = {
    bucket: getEnv("s3BucketName"),
    keyName: getEnv("s3KeywordKeyName"),
    region: getEnv("region"),
};
exports.s3 = s3;
const tweetsCountToRetrieve = 40;
exports.tweetsCountToRetrieve = tweetsCountToRetrieve;
