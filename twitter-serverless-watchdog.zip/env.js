"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv = __importStar(require("dotenv"));
dotenv.config();
const getEnv = (name) => {
    const result = process.env[name];
    if (result === undefined) {
        throw new Error(`environment variable "${name}" not defined`);
    }
    return result;
};
const dynamoDbTableName = getEnv("dynamoDbTableName");
exports.dynamoDbTableName = dynamoDbTableName;
const dynamoDbKeyName = getEnv("dynamoDbKeyName");
exports.dynamoDbKeyName = dynamoDbKeyName;
const dynamoDbKeyValue = getEnv("dynamoDbKeyValue");
exports.dynamoDbKeyValue = dynamoDbKeyValue;
const tweetsCountToRetrieve = 40;
exports.tweetsCountToRetrieve = tweetsCountToRetrieve;
