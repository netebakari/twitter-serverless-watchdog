"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable @typescript-eslint/no-explicit-any */
const util = __importStar(require("./util"));
const assert_1 = require("assert");
function AssertsS3(arg) {
    util.mustBeObject(arg);
    util.mustBeString(arg, "bucket");
    util.mustBeString(arg, "key");
}
exports.AssertsS3 = AssertsS3;
function AssertsTokenType(arg) {
    util.mustBeObject(arg);
    util.mustBeString(arg, "consumer_key");
    util.mustBeString(arg, "consumer_secret");
    util.mustBeString(arg, "access_token");
    util.mustBeString(arg, "access_token_secret");
}
exports.AssertsTokenType = AssertsTokenType;
function AssertsConfigRecord(arg) {
    util.mustBeObject(arg);
    util.mustBeString(arg, "lastId", true);
    if (!Array.isArray(arg.keywords)) {
        throw new assert_1.AssertionError({ message: "arg.keywords is not an Array", actual: arg.keywords });
    }
    if (arg.keywords.length === 0) {
        throw new assert_1.AssertionError({ message: "arg.keywords is empty", actual: arg.keywords });
    }
    for (const item of arg.keywords) {
        if (typeof item !== "string") {
            throw new assert_1.AssertionError({ message: "arg.keywords contains non-string value", actual: item });
        }
        try {
            new RegExp(item);
        }
        catch (e) {
            throw new assert_1.AssertionError({ message: "arg.keywords contains malformed regular expression", actual: item });
        }
    }
    if (!Array.isArray(arg.screenNames)) {
        throw new assert_1.AssertionError({ message: "arg.screenNames is not an Array", actual: arg.keywords });
    }
    if (arg.screenNames.length === 0) {
        throw new assert_1.AssertionError({ message: "arg.screenNames is empty", actual: arg.keywords });
    }
    for (const item of arg.screenNames) {
        if (typeof item !== "string") {
            throw new assert_1.AssertionError({ message: "arg.screenNames contains non-string value", actual: item });
        }
    }
    AssertsTokenType(arg.token);
    AssertsS3(arg.s3);
}
exports.AssertsConfigRecord = AssertsConfigRecord;
