"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable @typescript-eslint/no-explicit-any */
const assert_1 = require("assert");
exports.mustBeString = (arg, propertyName, undefinedAllowed = false) => {
    const value = arg[propertyName];
    if (undefinedAllowed) {
        if (value !== undefined && typeof value !== "string") {
            throw new assert_1.AssertionError({ message: `arg.${propertyName} is neigther undefined not string`, actual: value });
        }
    }
    else {
        if (typeof value !== "string") {
            throw new assert_1.AssertionError({ message: `arg.${propertyName} is not string`, actual: value });
        }
    }
};
exports.mustBeObject = (arg) => {
    if (arg === undefined) {
        throw new assert_1.AssertionError({ message: "arg is undefined" });
    }
    if (arg === null) {
        throw new assert_1.AssertionError({ message: "arg is null" });
    }
    if (typeof arg !== "object") {
        throw new assert_1.AssertionError({ message: "arg is not object" });
    }
};
