"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const env = __importStar(require("./env"));
const AWS = __importStar(require("aws-sdk"));
const _ = __importStar(require("lodash"));
const dynamo = new AWS.DynamoDB.DocumentClient({ region: env.dynamoDb.region });
/**
 * DynamoDBの設定を読み書きするクラス
 */
class ConfigOnDynamoDb {
    constructor(dryRun = false) {
        this.dryRun = dryRun;
    }
    /**
     * DynamoDB上の設定レコードを取得する。内部に元の値を保持しているので値を書き換えても特に影響はない
     */
    async getConfig() {
        const data = await dynamo
            .query({
            TableName: env.dynamoDb.tableName,
            KeyConditionExpression: "#key = :val",
            ExpressionAttributeNames: { "#key": env.dynamoDb.keyName },
            ExpressionAttributeValues: { ":val": env.dynamoDb.keyValue },
        })
            .promise();
        if (!data || !Array.isArray(data.Items) || data.Items.length === 0) {
            throw new Error("レコードが取れません");
        }
        this.record = data.Items[0];
        return _.cloneDeep(this.record);
    }
    /**
     * DynamoDB上の設定レコードの中のsinceId（レコード上はlastId）を更新する
     */
    async updateSinceId(sinceId) {
        if (this.record === undefined) {
            throw new Error("call getConfig() first");
        }
        if (this.dryRun) {
            console.log("DynamoDBの更新はスキップします");
        }
        else {
            console.log(`DynamoDBを更新します: sinceId=${sinceId}`);
            this.record.lastId = sinceId;
            await dynamo.put({ TableName: env.dynamoDb.tableName, Item: this.record }).promise();
        }
    }
}
exports.default = ConfigOnDynamoDb;
